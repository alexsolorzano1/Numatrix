export const UserModel = {
    "id": 3,
    "firts_name": "Jhon",
    "last_name": "Mamani Mamani",
    "age": 45,
    "height": 67,
    "height": 68,
    "year": 15,
    "created":new Date('2017-01-03')
}
export let AlimentosUser =  [
    {
      "id": 54,
      "name": "manzana",
      "consumed ": new Date(2021,10,31,18,24,0),
      "calories": 70
    },
    {
        "id": 55,
        "name": "manzana",
        "consumed ": new Date(2021,10,31,12,24,0),
        "calories": 70
    },
    {
        "id": 56,
        "name": "pera",
        "consumed ": new Date(2021,10,31,9,24,0),
        "calories": 70
    },
    {
        "id": 57,
        "name": "manzana",
        "consumed ": new Date(2021,10,30,18,24,0),
        "calories": 70
    },
    {
        "id": 58,
        "name": "Platano",
        "consumed ": new Date(2021,10,39,17,24,0),
        "calories": 70
    },
]
  