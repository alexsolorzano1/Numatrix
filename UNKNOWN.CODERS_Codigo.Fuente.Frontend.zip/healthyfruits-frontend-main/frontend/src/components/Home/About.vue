<template>
  <div class="mx-auto justify-content-center pt-5">
    <b-row align-h="center">
      <b-col
        style="color: white"
        xl="8"
        lg="9"
        md="9"
        sm="12"
        class="c-tra text-center text-barlow"
      >
        <h2>ACERCA DE NOSOTROS</h2>
        <hr class="bg-white mt-3 mb-5 w-75" />
        <h3>¿QUIENES SOMOS?</h3>
        <hr class="bg-white mt-1 mb-2 w-50" />
        <h5 class="mb-5">
          Somos una pagina que ofrece los servicos de recomendacion de alimentos
          y planes alimenticios.
        </h5>
        
        <h3>¿CUAL ES NUESTRO OBJETIVO?</h3>
        <hr class="bg-white mt-1 mb-2 w-75" />
        <h5 class="mb-5">
          Buscamos que las personas que utilicen nuestro aplicactivo puedan
          mejorar su alimentacion mediante las recomendaciones que se le de.
        </h5>
       
        <h3>¿CUAL ES NUESTRA VISION?</h3>
        <hr class="bg-white mt-1 mb-2 w-75" />
        <h5>
          En un futuro se quiere agrgar mas funcionalidades a nuestra aplicacion
          que puedan ser de utilidad para nuestros usuarios.
        </h5>
      </b-col>
    </b-row>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {};
  },
  components: {},
  methods: {},
};
</script>
<style scoped>
.c-tra {
  padding: 50px;
  border-radius: 50px;
  /*background: rgba(0, 0, 0, 0.2);*/
}
</style>>
